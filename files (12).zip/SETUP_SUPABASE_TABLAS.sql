-- ══════════════════════════════════════════════════════════════
-- ABC TERRITORIAL INTELLIGENCE — Setup Supabase Tables
-- Ejecuta este SQL en Supabase → SQL Editor → Run
-- ══════════════════════════════════════════════════════════════

-- Enable RLS
ALTER TABLE IF EXISTS public.lands ENABLE ROW LEVEL SECURITY;

-- Lands table (terrenos de propietarios)
CREATE TABLE IF NOT EXISTS public.lands (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  province TEXT,
  uso_actual TEXT,
  geojson JSONB,
  area_m2 NUMERIC,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- GIS Analyses
CREATE TABLE IF NOT EXISTS public.gis_analyses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  land_id UUID REFERENCES public.lands(id) ON DELETE CASCADE,
  owner_id UUID REFERENCES auth.users(id),
  score INTEGER,
  score_raw INTEGER,
  metrics JSONB,
  rlvm JSONB,
  restrictions JSONB,
  breakdown JSONB,
  status TEXT DEFAULT 'completed',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Investment access requests
CREATE TABLE IF NOT EXISTS public.investment_requests (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  nombre TEXT,
  email TEXT,
  phone TEXT,
  monto_disponible TEXT,
  mensaje TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS Policies
CREATE POLICY IF NOT EXISTS "Users see own lands" ON public.lands
  FOR ALL USING (auth.uid() = owner_id);

CREATE POLICY IF NOT EXISTS "Users see own analyses" ON public.gis_analyses
  FOR ALL USING (auth.uid() = owner_id);

CREATE POLICY IF NOT EXISTS "Anyone can insert investment requests" ON public.investment_requests
  FOR INSERT WITH CHECK (true);

CREATE POLICY IF NOT EXISTS "Admins see all investment requests" ON public.investment_requests
  FOR SELECT USING (true);

-- Supabase Storage bucket for documents
INSERT INTO storage.buckets (id, name, public)
VALUES ('documents', 'documents', false)
ON CONFLICT DO NOTHING;

CREATE POLICY IF NOT EXISTS "Users access own documents" ON storage.objects
  FOR ALL USING (auth.uid()::text = (storage.foldername(name))[1]);

-- Verify
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name IN ('lands','gis_analyses','investment_requests','gis_layers','gis_features');
