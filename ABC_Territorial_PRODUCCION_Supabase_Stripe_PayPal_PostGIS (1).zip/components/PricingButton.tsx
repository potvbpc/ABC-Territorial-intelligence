"use client";
import { useState } from "react";

export function PricingButton({ planId, email, userId, children, className = "" }: any) {
  const [loading, setLoading] = useState(false);
  async function checkout() {
    setLoading(true);
    try {
      const res = await fetch("/api/create-checkout-session", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId, email, userId }),
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else alert(data.error || "No se pudo iniciar el pago.");
    } finally { setLoading(false); }
  }
  return <button onClick={checkout} disabled={loading} className={className}>{loading ? "Procesando..." : children}</button>;
}
