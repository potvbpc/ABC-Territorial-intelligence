"use client";
import { useState } from "react";

export function PayPalBackupButton({ planId, userId, children = "Pagar con PayPal", className = "" }: any) {
  const [loading, setLoading] = useState(false);
  async function payWithPayPal() {
    setLoading(true);
    try {
      const response = await fetch("/api/paypal/create-order", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ planId, userId }),
      });
      const data = await response.json();
      if (!response.ok || !data.approveUrl) { alert(data.error || "No se pudo crear el pago PayPal."); return; }
      window.location.href = data.approveUrl;
    } finally { setLoading(false); }
  }
  return <button onClick={payWithPayPal} disabled={loading} className={className}>{loading ? "Conectando con PayPal..." : children}</button>;
}
