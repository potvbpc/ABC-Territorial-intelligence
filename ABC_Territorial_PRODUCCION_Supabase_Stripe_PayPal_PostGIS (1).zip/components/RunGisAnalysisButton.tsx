"use client";
import { useState } from "react";

export function RunGisAnalysisButton({ landId, onResult, className = "" }: any) {
  const [loading, setLoading] = useState(false);
  async function runAnalysis() {
    setLoading(true);
    try {
      const res = await fetch("/api/gis/run-analysis", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ landId }),
      });
      const data = await res.json();
      if (!res.ok) { alert(data.error || "No se pudo ejecutar el análisis GIS."); return; }
      onResult?.(data.result);
      alert("Análisis GIS completado.");
    } finally { setLoading(false); }
  }
  return <button onClick={runAnalysis} disabled={loading} className={className}>{loading ? "Analizando..." : "Generar diagnóstico GIS real"}</button>;
}
