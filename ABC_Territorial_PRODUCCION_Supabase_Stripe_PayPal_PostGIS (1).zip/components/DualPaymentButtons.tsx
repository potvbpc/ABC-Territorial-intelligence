"use client";
import { PricingButton } from "@/components/PricingButton";
import { PayPalBackupButton } from "@/components/PayPalBackupButton";

export function DualPaymentButtons({ planId, email, userId }: any) {
  return (
    <div className="grid gap-2">
      <PricingButton planId={planId} email={email} userId={userId} className="rounded-xl bg-blue-600 px-5 py-3 font-bold text-white">
        Pagar con tarjeta
      </PricingButton>
      <PayPalBackupButton planId={planId} userId={userId} className="rounded-xl border border-white/20 px-5 py-3 font-bold text-white">
        Pagar con PayPal
      </PayPalBackupButton>
    </div>
  );
}
