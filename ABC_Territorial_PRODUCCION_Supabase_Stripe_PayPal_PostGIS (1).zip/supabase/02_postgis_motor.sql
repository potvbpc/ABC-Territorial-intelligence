create extension if not exists postgis;

create table if not exists public.gis_layers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  layer_type text not null,
  source_name text,
  source_url text,
  is_active boolean default true,
  is_critical boolean default false,
  weight numeric default 10,
  created_at timestamptz default now()
);

create table if not exists public.gis_features (
  id uuid primary key default gen_random_uuid(),
  layer_id uuid references public.gis_layers(id) on delete cascade,
  name text,
  properties jsonb default '{}'::jsonb,
  geom geometry(Geometry, 4326) not null,
  created_at timestamptz default now()
);

create index if not exists gis_features_geom_idx on public.gis_features using gist (geom);
create index if not exists lands_geom_idx on public.lands using gist (geometry);

create or replace function public.create_land_from_geojson(
  p_owner_id uuid, p_name text, p_zone text, p_area_m2 numeric, p_geojson_geometry text
)
returns uuid language plpgsql security definer as $$
declare v_land_id uuid; v_geom geometry(Polygon,4326);
begin
  v_geom := st_setsrid(st_geomfromgeojson(p_geojson_geometry),4326);
  insert into public.lands(owner_id,name,zone,area_m2,geometry)
  values(p_owner_id,p_name,p_zone,coalesce(p_area_m2,round(st_area(geography(v_geom))::numeric,2)),v_geom)
  returning id into v_land_id;
  return v_land_id;
end;
$$;

create or replace function public.detect_land_critical_alerts(p_land_id uuid)
returns table(layer_name text, layer_type text, feature_name text, severity text, intersection_area_m2 numeric, blocks_publication boolean)
language sql stable as $$
  select gl.name, gl.layer_type, coalesce(f.name,'Sin nombre'),
  case when gl.layer_type='area_protegida' then 'critica' when gl.layer_type like 'riesgo%' then 'alta' else 'media' end,
  round(st_area(geography(st_intersection(l.geometry, f.geom)))::numeric,2),
  case when gl.is_critical=true or gl.layer_type='area_protegida' then true else false end
  from public.lands l
  join public.gis_features f on st_intersects(l.geometry, f.geom)
  join public.gis_layers gl on gl.id=f.layer_id
  where l.id=p_land_id and gl.is_active=true and gl.layer_type in ('area_protegida','riesgo_inundacion','riesgo_ambiental');
$$;

create or replace function public.run_land_gis_analysis(p_land_id uuid)
returns jsonb language plpgsql security definer as $$
declare v_alert_count int; v_block_count int; v_score numeric; v_risk text; v_compliance numeric;
begin
  select count(*), count(*) filter (where blocks_publication=true) into v_alert_count, v_block_count
  from public.detect_land_critical_alerts(p_land_id);

  v_compliance := 82;

  if v_block_count > 0 then v_score := 45; v_risk := 'critico';
  elsif v_alert_count > 0 then v_score := 68; v_risk := 'alto';
  else v_score := 78; v_risk := 'bajo';
  end if;

  delete from public.analysis_alerts where land_id=p_land_id;

  insert into public.analysis_alerts(land_id,severity,alert_type,title,description,recommended_action,blocks_publication)
  select p_land_id,severity,layer_type,'Coincidencia con '||layer_name,
  'El terreno intersecta con la capa '||layer_name||'. Área estimada: '||intersection_area_m2||' m².',
  case when blocks_publication then 'Bloquear publicación hasta validación técnica ABC.' else 'Solicitar revisión técnica complementaria.' end,
  blocks_publication
  from public.detect_land_critical_alerts(p_land_id);

  update public.lands set score=v_score, risk_status=v_risk where id=p_land_id;

  return jsonb_build_object(
    'land_id',p_land_id,
    'score',v_score,
    'risk_status',v_risk,
    'abc_compliance_score',v_compliance,
    'critical_alerts',v_alert_count,
    'publication_blocked',v_block_count>0,
    'disclaimer','El análisis normativo ABC es orientativo y no sustituye permisos oficiales.'
  );
end;
$$;
