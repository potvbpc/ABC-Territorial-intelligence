create extension if not exists postgis;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  role text check (role in ('propietario','inversionista','admin')) default 'propietario',
  plan text default 'explorador',
  payment_status text default 'inactive',
  stripe_customer_id text,
  stripe_subscription_id text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  provider text default 'stripe',
  provider_payment_id text unique,
  stripe_customer_id text,
  stripe_subscription_id text,
  plan_id text,
  amount_total bigint,
  currency text,
  status text,
  created_at timestamptz default now()
);

create table if not exists public.app_config (
  id text primary key default 'main',
  platform_name text default 'ABC Territorial Intelligence',
  logo_url text,
  primary_color text default '#1565C0',
  accent_color text default '#F2C94C',
  updated_at timestamptz default now()
);

insert into public.app_config (id) values ('main') on conflict (id) do nothing;

create table if not exists public.lands (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  name text not null,
  zone text,
  area_m2 numeric,
  geometry geometry(Polygon, 4326),
  score numeric,
  risk_status text default 'pending',
  created_at timestamptz default now()
);

create table if not exists public.analysis_alerts (
  id uuid primary key default gen_random_uuid(),
  land_id uuid references public.lands(id) on delete cascade,
  severity text default 'media',
  alert_type text,
  title text,
  description text,
  recommended_action text,
  blocks_publication boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.abc_compliance_rules (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  recommended_value text,
  impact text,
  category text default 'Edificabilidad',
  weight numeric default 10,
  is_active boolean default true,
  created_at timestamptz default now()
);

insert into public.abc_compliance_rules (name, recommended_value, impact, category, weight) values
('Altura recomendada','3 niveles','Controla escala urbana y reduce conflicto funcional.','Edificabilidad',20),
('Ocupación máxima sugerida','55% del lote','Permite ventilación, áreas verdes, drenaje y maniobra.','Edificabilidad',20),
('Retiro frontal sugerido','6.00 m','Mejora acceso, parqueos y relación con vía pública.','Frente urbano',15),
('Parqueos mínimos sugeridos','1 parqueo / 35 m² comercial','Reduce saturación vial y mejora operación.','Movilidad',15),
('Área permeable recomendada','20% mínimo','Reduce riesgo pluvial y mejora sostenibilidad.','Sostenibilidad',20)
on conflict do nothing;

create table if not exists public.opportunities (
  id uuid primary key default gen_random_uuid(),
  land_id uuid references public.lands(id) on delete set null,
  owner_id uuid references auth.users(id) on delete set null,
  title text not null,
  project_type text,
  zone text,
  investment_label text,
  roi_label text,
  status text default 'En estructuración',
  exact_location_hidden boolean default true,
  is_published boolean default false,
  created_at timestamptz default now()
);

create table if not exists public.investor_requests (
  id uuid primary key default gen_random_uuid(),
  investor_id uuid references auth.users(id) on delete cascade,
  opportunity_id uuid references public.opportunities(id) on delete cascade,
  status text default 'pending',
  nda_accepted boolean default false,
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;
alter table public.payments enable row level security;
alter table public.app_config enable row level security;
alter table public.lands enable row level security;
alter table public.analysis_alerts enable row level security;
alter table public.abc_compliance_rules enable row level security;
alter table public.opportunities enable row level security;
alter table public.investor_requests enable row level security;

create policy "Users read own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users update own profile" on public.profiles for update using (auth.uid() = id);
create policy "Users read own payments" on public.payments for select using (auth.uid() = user_id);
create policy "Config public read" on public.app_config for select using (true);
create policy "Rules public read" on public.abc_compliance_rules for select using (is_active = true);
create policy "Owners read own lands" on public.lands for select using (auth.uid() = owner_id);
create policy "Owners insert own lands" on public.lands for insert with check (auth.uid() = owner_id);
create policy "Owners update own lands" on public.lands for update using (auth.uid() = owner_id);
create policy "Published opportunities visible" on public.opportunities for select using (is_published = true or auth.uid() = owner_id);
create policy "Investors create own requests" on public.investor_requests for insert with check (auth.uid() = investor_id);
create policy "Investors read own requests" on public.investor_requests for select using (auth.uid() = investor_id);

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', 'Usuario'))
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
