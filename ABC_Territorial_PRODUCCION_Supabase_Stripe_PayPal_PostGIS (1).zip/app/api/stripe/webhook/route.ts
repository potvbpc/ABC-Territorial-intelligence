import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { supabaseAdmin } from "@/lib/supabaseAdmin";
import Stripe from "stripe";

export async function POST(req: NextRequest) {
  const body = await req.text();
  const signature = req.headers.get("stripe-signature");
  if (!signature) return NextResponse.json({ error: "Missing signature" }, { status: 400 });

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET!);
  } catch {
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as Stripe.Checkout.Session;
    const userId = session.metadata?.userId || null;
    const planId = session.metadata?.planId || "unknown";
    await supabaseAdmin.from("payments").upsert({
      user_id: userId,
      provider: "stripe",
      provider_payment_id: session.id,
      stripe_customer_id: String(session.customer || ""),
      stripe_subscription_id: session.subscription ? String(session.subscription) : null,
      plan_id: planId,
      amount_total: session.amount_total,
      currency: session.currency,
      status: session.payment_status,
    }, { onConflict: "provider_payment_id" });

    if (userId) {
      await supabaseAdmin.from("profiles").update({
        plan: planId,
        payment_status: "active",
        stripe_customer_id: String(session.customer || ""),
        stripe_subscription_id: session.subscription ? String(session.subscription) : null,
        updated_at: new Date().toISOString(),
      }).eq("id", userId);
    }
  }

  return NextResponse.json({ received: true });
}
