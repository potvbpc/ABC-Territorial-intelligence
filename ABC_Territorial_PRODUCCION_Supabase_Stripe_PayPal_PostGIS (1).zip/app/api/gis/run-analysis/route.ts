import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function POST(req: NextRequest) {
  const { landId } = await req.json();
  if (!landId) return NextResponse.json({ error: "Falta landId" }, { status: 400 });
  const { data, error } = await supabaseAdmin.rpc("run_land_gis_analysis", { p_land_id: landId });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ result: data });
}
