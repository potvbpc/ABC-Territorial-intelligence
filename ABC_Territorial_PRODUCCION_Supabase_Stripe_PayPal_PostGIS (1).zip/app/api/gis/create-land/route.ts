import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function POST(req: NextRequest) {
  const { ownerId, name, zone, areaM2, geojson } = await req.json();
  const geometryText = JSON.stringify(geojson.geometry || geojson);
  const { data, error } = await supabaseAdmin.rpc("create_land_from_geojson", {
    p_owner_id: ownerId,
    p_name: name,
    p_zone: zone || null,
    p_area_m2: areaM2 || null,
    p_geojson_geometry: geometryText,
  });
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ landId: data });
}
