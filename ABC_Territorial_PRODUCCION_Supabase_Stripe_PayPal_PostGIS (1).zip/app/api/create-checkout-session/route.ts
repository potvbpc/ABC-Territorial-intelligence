import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";

const planMap: any = {
  owner_professional: { price: process.env.STRIPE_PRICE_OWNER_PROFESSIONAL, mode: "payment" },
  owner_premium: { price: process.env.STRIPE_PRICE_OWNER_PREMIUM, mode: "payment" },
  owner_validated: { price: process.env.STRIPE_PRICE_OWNER_VALIDATED, mode: "payment" },
  investor_professional: { price: process.env.STRIPE_PRICE_INVESTOR_PROFESSIONAL, mode: "subscription" },
  investor_deal_access: { price: process.env.STRIPE_PRICE_INVESTOR_DEAL_ACCESS, mode: "subscription" },
};

export async function POST(req: NextRequest) {
  const { planId, email, userId } = await req.json();
  const p = planMap[planId];
  if (!p?.price) return NextResponse.json({ error: "Plan no configurado" }, { status: 400 });

  const session = await stripe.checkout.sessions.create({
    mode: p.mode,
    line_items: [{ price: p.price, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/payment/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/payment/cancel`,
    customer_email: email,
    metadata: { planId, userId: userId || "" },
    allow_promotion_codes: true,
  });

  return NextResponse.json({ url: session.url });
}
