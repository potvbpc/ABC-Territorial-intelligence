import { NextRequest, NextResponse } from "next/server";
import { capturePayPalOrder } from "@/lib/paypal";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function POST(req: NextRequest) {
  const { orderId, planId, userId } = await req.json();
  const capture = await capturePayPalOrder(orderId);

  if (capture.status === "COMPLETED") {
    const captureInfo = capture.purchase_units?.[0]?.payments?.captures?.[0];
    await supabaseAdmin.from("payments").insert({
      user_id: userId || null,
      provider: "paypal",
      provider_payment_id: `paypal_${orderId}`,
      plan_id: planId || "paypal_manual",
      amount_total: Math.round(Number(captureInfo?.amount?.value || 0) * 100),
      currency: captureInfo?.amount?.currency_code || "USD",
      status: "paypal_completed",
    });

    if (userId) {
      await supabaseAdmin.from("profiles").update({
        plan: planId || "paypal_manual",
        payment_status: "active",
        updated_at: new Date().toISOString(),
      }).eq("id", userId);
    }
  }

  return NextResponse.json({ capture });
}
