import { NextRequest, NextResponse } from "next/server";
import { createPayPalOrder } from "@/lib/paypal";

const paypalPlans: any = {
  owner_professional: { amount: "199.00", description: "ABC Territorial - Propietario Profesional" },
  owner_premium: { amount: "950.00", description: "ABC Territorial - Propietario Premium" },
  owner_validated: { amount: "2500.00", description: "ABC Territorial - Validado ABC" },
  investor_professional: { amount: "149.00", description: "ABC Territorial - Inversionista Profesional" },
  investor_deal_access: { amount: "750.00", description: "ABC Territorial - Deal Access" },
};

export async function POST(req: NextRequest) {
  const { planId } = await req.json();
  const plan = paypalPlans[planId];
  if (!plan) return NextResponse.json({ error: "Plan PayPal no configurado" }, { status: 400 });
  const order = await createPayPalOrder({ amount: plan.amount, description: plan.description, planId });
  const approveUrl = order.links?.find((link: any) => link.rel === "approve")?.href;
  return NextResponse.json({ orderId: order.id, approveUrl });
}
