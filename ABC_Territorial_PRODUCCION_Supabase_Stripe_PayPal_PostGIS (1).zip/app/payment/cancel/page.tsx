export default function Page() {
  return <main style={{padding:40,fontFamily:"Arial"}}><h1>Pago cancelado</h1><a href="/">Volver</a></main>;
}
