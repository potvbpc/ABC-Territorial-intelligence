export default function Page() {
  return <main style={{padding:40,fontFamily:"Arial"}}><h1>Pago recibido correctamente</h1><p>Tu acceso será activado automáticamente.</p><a href="/">Volver</a></main>;
}
