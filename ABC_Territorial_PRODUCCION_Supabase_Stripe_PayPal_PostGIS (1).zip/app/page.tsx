"use client";

import { DualPaymentButtons } from "@/components/DualPaymentButtons";
import { useState } from "react";

const plans = [
  ["Propietario Profesional", "US$199", "owner_professional", "Diagnóstico completo + score + sugerencias."],
  ["Propietario Premium", "US$950", "owner_premium", "Ficha de activación + dashboard + modelo preliminar."],
  ["Validado ABC", "US$2,500", "owner_validated", "Validación técnica + publicación privada."],
  ["Inversionista Profesional", "US$149/mes", "investor_professional", "Fichas completas + filtros avanzados."],
  ["Deal Access", "US$750/mes", "investor_deal_access", "Acceso ampliado + conexión vía ABC."]
];

export default function Page() {
  return (
    <main style={{minHeight:"100vh",background:"#061019",color:"#E8EDF3",fontFamily:"Arial",padding:24}}>
      <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",borderBottom:"1px solid rgba(255,255,255,.1)",paddingBottom:20}}>
        <div>
          <h1 style={{margin:0,fontSize:34}}>ABC Territorial Intelligence</h1>
          <p style={{color:"#9AA4B2"}}>Transformamos terrenos en oportunidades estructuradas de inversión.</p>
        </div>
      </header>

      <section style={{display:"grid",gridTemplateColumns:"1fr 460px",gap:24,marginTop:32}}>
        <div>
          <h2 style={{fontSize:54,lineHeight:1.05}}>Inteligencia territorial, normativa ABC y conexión con inversionistas.</h2>
          <p style={{fontSize:18,color:"#CBD5E1",lineHeight:1.7}}>Plataforma SaaS + GIS + Marketplace para propietarios de terrenos e inversionistas.</p>
        </div>
        <div style={{border:"1px solid rgba(255,255,255,.1)",borderRadius:24,padding:18,background:"rgba(255,255,255,.04)"}}>
          <div style={{height:280,borderRadius:18,background:"linear-gradient(135deg,#07131e,#0B1D33)",position:"relative",overflow:"hidden"}}>
            <div style={{position:"absolute",left:"24%",top:"22%",width:"46%",height:"40%",clipPath:"polygon(10% 20%,70% 5%,98% 55%,58% 88%,0 70%)",background:"rgba(21,101,192,.35)",border:"3px solid #42A5F5"}} />
          </div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginTop:12}}>
            <Stat title="Score" value="78" color="#2ECC71"/>
            <Stat title="Cumplimiento" value="82%" color="#F2C94C"/>
            <Stat title="Valor" value="3.8x" color="#42A5F5"/>
          </div>
        </div>
      </section>

      <section style={{marginTop:48}}>
        <h2>Planes activos</h2>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:18}}>
          {plans.map(([name, price, id, desc]) => (
            <div key={id} style={{border:"1px solid rgba(255,255,255,.1)",borderRadius:24,padding:22,background:"rgba(255,255,255,.04)"}}>
              <h3>{name}</h3>
              <h2 style={{color:"#F2C94C"}}>{price}</h2>
              <p style={{color:"#9AA4B2"}}>{desc}</p>
              <DualPaymentButtons planId={id} />
            </div>
          ))}
        </div>
      </section>

      <section style={{marginTop:48,border:"1px solid rgba(242,201,76,.25)",borderRadius:24,padding:22,background:"rgba(242,201,76,.06)"}}>
        <h2>Análisis de Cumplimiento Normativo ABC</h2>
        <p style={{color:"#CBD5E1"}}>Módulo adicional basado en lineamientos propuestos por ABC Projects para orientar edificabilidad, calidad urbanística y funcionalidad. No sustituye permisos oficiales.</p>
      </section>
    </main>
  );
}

function Stat({title,value,color}:any){
  return <div style={{border:"1px solid rgba(255,255,255,.1)",borderRadius:16,padding:14,background:"rgba(0,0,0,.25)"}}><small style={{color:"#9AA4B2"}}>{title}</small><b style={{display:"block",fontSize:28,color}}>{value}</b></div>
}
