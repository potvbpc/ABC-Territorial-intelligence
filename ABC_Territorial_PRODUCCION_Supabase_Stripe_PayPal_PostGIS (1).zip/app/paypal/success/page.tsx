"use client";
import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

export default function PayPalSuccessPage() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("token");
  const planId = searchParams.get("plan");
  const [status, setStatus] = useState("Confirmando pago PayPal...");

  useEffect(() => {
    async function capture() {
      const response = await fetch("/api/paypal/capture-order", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ orderId, planId }),
      });
      const data = await response.json();
      setStatus(response.ok && data.capture?.status === "COMPLETED" ? "Pago PayPal confirmado correctamente." : "No se pudo confirmar el pago.");
    }
    if (orderId) capture();
  }, [orderId, planId]);

  return <main style={{padding:40,fontFamily:"Arial"}}><h1>{status}</h1><a href="/">Volver</a></main>;
}
